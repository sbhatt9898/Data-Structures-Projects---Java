/**Author:Swadha Bhatt
Assignment Number: Assignment2, Question 2

Purpose:
- The program should simulate the Josephus problem by repeatedly removing the n-th name from the list and displaying it
- At the end, display the name of the survivor

Input: 
- How many soldiers?
- Type 10 soldiers name
- Step size

Output: 
- Elimination order of soldiers
- Survivor's name

Procedure Called:
- collectUserInput(Scanner scanner)
- getStep(Scanner scanner)
- solveJosephus(List<String> names, int step)
- displayResults(List<String> eliminatedOrder, String survivor)
*/
package Assignment2;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class A2_Q2 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<String> soldiersNames = collectUserInput(scanner);
        int step = getStep(scanner);
        List<String> eliminatedOrder = solveJosephus(new ArrayList<>(soldiersNames), step);
        displayResults(eliminatedOrder, soldiersNames.get(0));
    }
    // Collects user input for the number of soldiers and their names
    private static List<String> collectUserInput(Scanner scanner) {
        System.out.print("How many soldiers? ");
        int numSoldiers = Integer.parseInt(scanner.nextLine());
        List<String> soldiersNames = new ArrayList<>();
        for (int i = 0; i < numSoldiers; i++) {
            System.out.print("Type soldier " + (i + 1) + " name: ");
            soldiersNames.add(scanner.nextLine());
        }
        return soldiersNames;
    }
    // Collects user input for the step size
    private static int getStep(Scanner scanner) {
        System.out.print("Enter the position: ");
        return Integer.parseInt(scanner.nextLine());
    }
    // Solves the Josephus problem by eliminating soldiers based on the step size
    private static List<String> solveJosephus(List<String> names, int step) {
        List<String> eliminatedOrder = new ArrayList<>();
        int index = 0;
        while (names.size() > 1) {
            index = (index + step - 1) % names.size();
            eliminatedOrder.add(names.remove(index));
        }
        return eliminatedOrder;
    }
    // Displays the elimination order and the survivor's name
    private static void displayResults(List<String> eliminatedOrder, String survivor) {
        System.out.println("\nEliminating order:");
        for (int i = 0; i < eliminatedOrder.size(); i++) {
            System.out.println((i + 1) + ". " + eliminatedOrder.get(i));
        }
        System.out.println("\nThe survivor is " + survivor + ".");
    }
}
