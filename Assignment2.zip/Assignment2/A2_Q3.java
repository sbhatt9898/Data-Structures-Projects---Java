/**Author:Swadha Bhatt
Assignment Number: Assignment2, Question 3

Purpose:
-finds the longest increasing sequence in a given 2D array
- using stack

Input:  2D array of integers

Output: 
- Longest increasing sequence

Procedure Called:
- longestSequence(int[][] array)
- printArray(int[][] array)
- printResults(int maxSum, long startTime, long stopTime)
- displayResults(List<Integer[]> sequence)
- generateArray()
*/
package Assignment2;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Random;

public class A2_Q3 {
	public static void main(String[] args) {
        int[][] randomArray = generateArray();
        int[][] homeworkArray = {{97, 47, 56, 36}, {35, 57, 41, 13}, {89, 36, 98, 75}, {25, 45, 26, 17}};

        System.out.println("Homework Array:");
        printArray(homeworkArray);
        List<Integer[]> homeworkSeq = longestSequence(homeworkArray);
        System.out.println("\nLongest Sequence in Homework Array:");
        displayResults(homeworkSeq);

        System.out.println("\nGenerated Array:");
        printArray(randomArray);
        List<Integer[]> generatedSeq = longestSequence(randomArray);
        System.out.println("\nLongest Sequence in Generated Array:");
        displayResults(generatedSeq);
    }
    private static final int ARRAY_SIZE = 4;

    private static class Position {
        int x, y;
        List<Integer[]> sequence;

        Position(int x, int y, List<Integer[]> sequence) {
            this.x = x;
            this.y = y;
            this.sequence = new ArrayList<>(sequence);
        }
    }
    // Finds the longest increasing sequence in the input array
    public static List<Integer[]> longestSequence(int[][] array) {
        int[][] directions = {{-1, 0}, {-1, 1}, {0, 1}, {1, 1}, {1, 0}, {1, -1}, {0, -1}, {-1, -1}};
        List<Integer[]> longestSeq = new ArrayList<>();

        for (int row = 0; row < ARRAY_SIZE; row++) {
            for (int col = 0; col < ARRAY_SIZE; col++) {
                Deque<Position> stack = new ArrayDeque<>();
                List<Integer[]> initialSequence = new ArrayList<>();
                initialSequence.add(new Integer[]{array[row][col], row, col});
                stack.push(new Position(row, col, initialSequence));

                while (!stack.isEmpty()) {
                    Position pos = stack.pop();
                    if (pos.sequence.size() > longestSeq.size()) {
                        longestSeq = new ArrayList<>(pos.sequence);
                    }

                    for (int[] dir : directions) {
                        int nx = pos.x + dir[0];
                        int ny = pos.y + dir[1];
                        if (nx >= 0 && nx < ARRAY_SIZE && ny >= 0 && ny < ARRAY_SIZE) {
                            Integer[] last = pos.sequence.get(pos.sequence.size() - 1);
                            int nextNumber = array[nx][ny];
                            if (nextNumber > last[0]) {
                                List<Integer[]> newSequence = new ArrayList<>(pos.sequence);
                                newSequence.add(new Integer[]{nextNumber, nx, ny});
                                stack.push(new Position(nx, ny, newSequence));
                            }
                        }
                    }
                }
            }
        }
        return longestSeq;
    }
    // Prints the elements of a 2D array
    public static void printArray(int[][] array) {
        for (int[] row : array) {
            for (int val : row) {
                System.out.printf("%4d", val);
            }
            System.out.println();
        }
    }
    // Displays the longest increasing sequence and its length
    public static void displayResults(List<Integer[]> sequence) {
        for (Integer[] numPos : sequence) {
            System.out.printf("%d \t(%d, %d)\n", numPos[0], numPos[1], numPos[2]);
        }
        System.out.printf("\nThe length of the sequence is: %d\n", sequence.size());
    }
    // Generates a random 2D array of integers
    public static int[][] generateArray() {
        int[][] array = new int[ARRAY_SIZE][ARRAY_SIZE];
        Random rand = new Random();
        for (int i = 0; i < ARRAY_SIZE; i++) {
            for (int j = 0; j < ARRAY_SIZE; j++) {
                array[i][j] = rand.nextInt(1001);
            }
        }
        return array;
    }

    
}
