/**Author:Swadha Bhatt
Assignment Number: Assignment2, Question 1

Purpose:
-4 different algorithms to find the maximum contiguous subsequence sum
-it generates arrays of various sizes filled with random integers 
-calculates the execution time for each algorithm

Input: none

Output: 
-maximum subsequence sum
-Execution time for each algorithm

Procedure Called:
- generateRandomArray(int size)
- isMajor(int[] arr, int element)
- printResults(int maxSum, long startTime, long stopTime)
- maxSubSum1(int[] a)
- maxSubSum2(int[] a)
- maxSubSum3(int[] a)
- maxSubSum4(int[] a)
*/
package Assignment2;

import java.util.Random;

public class A2_Q1 {
	public static void main(String[] args) {
		final int[] ARRAY_SIZES = { 5000, 10000, 50000, 100000, 200000 };

		for (int size : ARRAY_SIZES) {
			System.out.println(size);

			int[] subsequenceArray = generateRandomArray(size);

			long startTime, stopTime;

			// Algorithm 1 - Cubic
			System.out.println("Cubic Maximum Contiguous Subsequence Sum");
			startTime = System.nanoTime();
			int maxSum1 = maxSubSum1(subsequenceArray);
			stopTime = System.nanoTime();
			printResults(maxSum1, startTime, stopTime);

			// Algorithm 2 - Quadratic
			System.out.println("Quadratic Maximum Contiguous Subsequence Sum");
			startTime = System.nanoTime();
			int maxSum2 = maxSubSum2(subsequenceArray);
			stopTime = System.nanoTime();
			printResults(maxSum2, startTime, stopTime);

			// Algorithm 3 - Recursive
			System.out.println("Recursive Maximum Contiguous Subsequence Sum");
			startTime = System.nanoTime();
			int maxSum3 = maxSubSum3(subsequenceArray);
			stopTime = System.nanoTime();
			printResults(maxSum3, startTime, stopTime);

			// Algorithm 4 - Linear
			System.out.println("Linear Maximum Contiguous Subsequence Sum");
			startTime = System.nanoTime();
			int maxSum4 = maxSubSum4(subsequenceArray);
			stopTime = System.nanoTime();
			printResults(maxSum4, startTime, stopTime);

			System.out.println();
		}
	}

	// Generates random arrays of integers
	public static int[] generateRandomArray(int size) {
		Random rand = new Random();
		int[] arr = new int[size];
		for (int i = 0; i < size; i++) {
			arr[i] = rand.nextInt(10001) - 5000;
		}
		return arr;
	}

	// Prints the maximum subsequence sum and execution time
	public static void printResults(int maxSum, long startTime, long stopTime) {
		System.out.println("The maximum subsequence sum is: " + maxSum);
		System.out.println("Execution Time: " + (stopTime - startTime) + " nanoseconds.\n");
	}

	// Cubic maximum contiguous subsequence sum algorithm
	public static int maxSubSum1(int[] a) {
		int maxSum = 0;
		for (int i = 0; i < a.length; i++) {
			for (int j = i; j < a.length; j++) {
				int thisSum = 0;
				for (int k = i; k <= j; k++) {
					thisSum += a[k];
				}

				if (thisSum > maxSum) {
					maxSum = thisSum;
				}
			}
		}
		return maxSum;
	}

	// Quadratic maximum contiguous subsequence sum algorithm
	public static int maxSubSum2(int[] a) {
		int maxSum = 0;
		for (int i = 0; i < a.length; i++) {
			int thisSum = 0;
			for (int j = i; j < a.length; j++) {
				thisSum += a[j];
				if (thisSum > maxSum) {
					maxSum = thisSum;
				}
			}
		}
		return maxSum;
	}

	// Recursive maximum contiguous subsequence sum algorithm
	private static int maxSumRec(int[] a, int left, int right) {
		if (left == right) {
			return Math.max(0, a[left]);
		}

		int center = (left + right) / 2;
		int maxLeftSum = maxSumRec(a, left, center);
		int maxRightSum = maxSumRec(a, center + 1, right);

		int maxLeftBorderSum = 0, leftBorderSum = 0;
		for (int i = center; i >= left; i--) {
			leftBorderSum += a[i];
			maxLeftBorderSum = Math.max(leftBorderSum, maxLeftBorderSum);
		}

		int maxRightBorderSum = 0, rightBorderSum = 0;
		for (int i = center + 1; i <= right; i++) {
			rightBorderSum += a[i];
			maxRightBorderSum = Math.max(rightBorderSum, maxRightBorderSum);
		}

		return Math.max(maxLeftSum, Math.max(maxRightSum, maxLeftBorderSum + maxRightBorderSum));
	}

	// call of Recursive maximum contiguous subsequence sum algorithm
	public static int maxSubSum3(int[] a) {
		return maxSumRec(a, 0, a.length - 1);
	}
	//Linear maximum contiguous subsequence sum algorithm
	public static int maxSubSum4(int[] a) {
		int maxSum = 0, thisSum = 0;
		for (int i = 0; i < a.length; i++) {
			thisSum += a[i];
			maxSum = Math.max(maxSum, thisSum);
			thisSum = Math.max(thisSum, 0);
		}
		return maxSum;
	}
}
